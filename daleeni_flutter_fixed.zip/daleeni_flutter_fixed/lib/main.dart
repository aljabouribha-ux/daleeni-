import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const DaleeniApp());
}

class DaleeniApp extends StatelessWidget {
  const DaleeniApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'دليني - Daleeni',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFFB300),
          brightness: Brightness.dark,
          primary: const Color(0xFFFFB300),
          surface: const Color(0xFF1E1E1E),
        ),
        scaffoldBackgroundColor: const Color(0xFF121212),
        textTheme: GoogleFonts.cairoTextTheme(ThemeData.dark().textTheme),
      ),
      home: const MainHomeScreen(),
    );
  }
}

class MainHomeScreen extends StatefulWidget {
  const MainHomeScreen({super.key});

  @override
  State<MainHomeScreen> createState() => _MainHomeScreenState();
}

class _MainHomeScreenState extends State<MainHomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    HomeDashboardTab(),
    BaghdadLiveNavigationScreen(),
    CharactersAndVehiclesScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (idx) => setState(() => _currentIndex = idx),
        backgroundColor: const Color(0xFF1A1A1A),
        indicatorColor: Colors.amber.withOpacity(0.2),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home, color: Colors.amber),
            label: 'الرئيسية',
          ),
          NavigationDestination(
            icon: Icon(Icons.map_outlined),
            selectedIcon: Icon(Icons.map, color: Colors.amber),
            label: 'خريطة بغداد',
          ),
          NavigationDestination(
            icon: Icon(Icons.garage_outlined),
            selectedIcon: Icon(Icons.directions_car, color: Colors.amber),
            label: 'الكراج والمرشدين',
          ),
        ],
      ),
    );
  }
}

class HomeDashboardTab extends StatelessWidget {
  const HomeDashboardTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تطبيق دليني (2026) - بغداد'),
        backgroundColor: const Color(0xFF1F1F1F),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [const Color(0xFF2A2A2A), const Color(0xFF1E1E1E)],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.amber.withOpacity(0.35)),
              ),
              child: Column(
                children: [
                  const Text(
                    'يا هلا بيك يا مهندس علي 🧭',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.amber),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'دليلك الذكي بكل شوارع بغداد (الكرخ والرصافة).\nصوت "الأسطة أبو الفن" وياك بالطريق يحچيلك الصح، وعجلتك جاهزة لكل مشوار!',
                    style: TextStyle(color: Colors.grey, height: 1.4),
                    textAlign: TextAlign.center,
                  ),
                  const Divider(color: Colors.white24, height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildMiniBadge('المركبة الحالية', 'سوناتا 2014', Icons.directions_car),
                      _buildMiniBadge('الصوت الفعال', 'الأسطة أبو الفن', Icons.record_voice_over),
                      _buildMiniBadge('حالة الطرق', 'مزدحم جزئياً', Icons.traffic),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const BaghdadLiveNavigationScreen()),
                );
              },
              icon: const Icon(Icons.navigation, color: Colors.black),
              label: const Text('بدء الملاحة الحية في بغداد (صوت الأسطة)'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.amber,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CharactersAndVehiclesScreen()),
                );
              },
              icon: const Icon(Icons.people_alt, color: Colors.amber),
              label: const Text('الشخصيات والمركبات المسجلة'),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.amber),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMiniBadge(String title, String val, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: Colors.amber, size: 20),
        const SizedBox(height: 4),
        Text(title, style: const TextStyle(fontSize: 10, color: Colors.white54)),
        Text(val, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white)),
      ],
    );
  }
}

class BaghdadLiveNavigationScreen extends StatelessWidget {
  const BaghdadLiveNavigationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الملاحة الحية - شوارع بغداد'),
        backgroundColor: const Color(0xFF1F1F1F),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.satellite_alt, size: 70, color: Colors.amber),
            const SizedBox(height: 16),
            const Text(
              'الرادار البغدادي الذكي نشط',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24.0),
              child: Text(
                'الأسطة أبو الفن يراقب طريقك: سريع محمد القاسم، جسر الجادرية، وشارع فلسطين.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CharactersAndVehiclesScreen extends StatelessWidget {
  const CharactersAndVehiclesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('شخصيات وعجلات دليني'),
        backgroundColor: const Color(0xFF1F1F1F),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildSectionTitle('الشخصيات الصوتية الذكية'),
          _buildCard('الأسطة أبو الفن', 'مرشد القيادة والصوت التراثي البغدادي الأصيل', Icons.mic),
          _buildCard('ست عذراء', 'التوجيه والإرشادات المنزلية والذكية', Icons.record_voice_over),
          _buildCard('الكابتن حيدري', 'مهندس النظام والتحكم الفائق', Icons.verified_user),
          const SizedBox(height: 20),
          _buildSectionTitle('المركبات المسجلة'),
          _buildCard('هيونداي سوناتا 2014 (محرك 2400)', 'مركبة السيد المهندس الشخصية', Icons.directions_car),
          _buildCard('سيارة دفع رباعي (SUV)', 'مناسبة للطرق الخارجية والرحلات', Icons.car_repair),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.amber),
      ),
    );
  }

  Widget _buildCard(String title, String subtitle, IconData icon) {
    return Card(
      color: const Color(0xFF1E1E1E),
      margin: const EdgeInsets.symmetric(vertical: 6.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.grey)),
        leading: Icon(icon, color: Colors.amber),
      ),
    );
  }
}
